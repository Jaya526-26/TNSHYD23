package publi;

public class E
{
protected void display()
{
	System.out.println("TNS sessions"); 
}
public class E extends F 
{
	F obj=new F();
	obj.display();
}
}
