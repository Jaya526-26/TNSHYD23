package two;

 class C {
	 int p=20;
	 static int q=30;



	}

