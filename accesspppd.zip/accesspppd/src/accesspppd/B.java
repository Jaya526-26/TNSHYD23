package accesspppd;

 class B
{
	void display()
	{
		System.out.println("ACCESS default");
	}
    public static void main(String[] args) 
	{
		B obj = new B();
		obj.display();

	}

}
