package one;

 class B {
	 int b=10;
	 static int c=30;
	 int display()
	 {
		 return 20;
	 }
	 static void display1()
	 {
		 System.out.println(10);
	 }

	public static void main(String[] args) {
		B b1=new B();
		System.out.println(b1.b);
		System.out.println(B.c);
		b1.display();
		B.display1();
		System.out.println(b1.display());

	}

}
 
