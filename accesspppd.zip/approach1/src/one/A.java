package one;

 class A {
int b=20;
static int c=30;
	public static void main(String[] args) 
	{
		int a=10;
		System.out.println(a);
		A a1=new A();
		System.out.println(a1.b);
		System.out.println(A.c);
		
	}

}
 
