package p2;
import P1.*;

public class G {

	public static void main(String[] args) {
		T obj=new T();
		obj.display();
		

	}

}
