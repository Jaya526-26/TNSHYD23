package publi;

public class C
{
	public void display()
	{
		System.out.println("TNS Sessions");
	}
}
