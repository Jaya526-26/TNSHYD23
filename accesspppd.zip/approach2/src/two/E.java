package two;

public class E {
int a=20;
static int b=30;
int display()
{
return 40;
}
static void display1()
{
	System.out.println(20);
}
}
