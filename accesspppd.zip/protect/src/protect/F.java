package protect;

public class F
{
protected void display()
{
	System.out.println("sessions");
}
}
