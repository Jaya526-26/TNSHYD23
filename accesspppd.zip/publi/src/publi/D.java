package publi;

public class D
{
public static void main(String[] args) {
	C obj=new C();
	obj.display();
}
}
