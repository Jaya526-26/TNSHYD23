package P1;

public class T {

	public void display() {
		System.out.println("userdefined");

	}

}
