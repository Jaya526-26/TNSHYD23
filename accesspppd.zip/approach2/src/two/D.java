package two;

public class D {

	public static void main(String[] args) {
	int r=90;
	System.out.println(r);
	C p1=new C();
	System.out.println(p1.p);
	System.out.println(C.q);

	}

}
