package two;

public class F {

	public static void main(String[] args) {
		E a1=new E();
		System.out.println(a1.a); 
		System.out.println(E.b);
		System.out.println(a1.display());
		a1.display();
		E.display1();

	}

}
